"""Loopback-only preview. No external fetch, push send, or calendar writes."""
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
import argparse
import json
from alert_core import Store

ROOT = Path(__file__).resolve().parent
FIXTURES = {'baseline': 'baseline.html', 'update': 'update.html', 'unavailable': 'unavailable.html', 'failure': 'failure.html'}

class Handler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()

    def valid_host(self):
        return self.headers.get('Host') in {f'localhost:{self.server.server_port}', f'127.0.0.1:{self.server.server_port}'}

    def respond(self, status, value):
        data = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if not self.valid_host():
            return self.respond(403, {'error': 'Loopback host required'})
        path = urlsplit(self.path).path
        if path == '/api/state':
            store = Store(self.server.db_path)
            try:
                self.respond(200, store.state())
            finally:
                store.close()
        elif path.startswith('/api/'):
            self.respond(404, {'error': 'Not found'})
        elif path in {'/', '/index.html', '/app.js', '/style.css', '/sw.js', '/manifest.webmanifest', '/icon.svg', '/icon-192.png', '/icon-512.png'}:
            super().do_GET()
        else:
            self.respond(404, {'error': 'Not found'})

    def do_POST(self):
        if not self.valid_host() or self.headers.get('Origin') != f'http://{self.headers.get("Host")}':
            return self.respond(403, {'error': 'Same-origin browser request required'})
        if self.headers.get('Content-Type') != 'application/json':
            return self.respond(415, {'error': 'JSON required'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 1024:
                return self.respond(413, {'error': 'Invalid request size'})
            payload = json.loads(self.rfile.read(length))
            step = payload.get('step')
            if urlsplit(self.path).path != '/api/demo' or not isinstance(step, str) or step not in FIXTURES:
                return self.respond(400, {'error': 'Unknown demo step'})
        except (ValueError, AttributeError):
            return self.respond(400, {'error': 'Invalid request'})
        store = Store(self.server.db_path)
        try:
            ids = store.ingest('demo-calendar', (ROOT / 'fixtures' / FIXTURES[step]).read_text())
            self.respond(200, {'newChanges': len(ids), 'state': store.state()})
        except ValueError as exc:
            self.respond(422, {'error': str(exc), 'state': store.state()})
        finally:
            store.close()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--port', type=int, default=8765)
    p.add_argument('--db', default=str(ROOT / 'demo.sqlite3'))
    args = p.parse_args()
    store = Store(args.db)
    if not store.state()['sources']:
        store.ingest('demo-calendar', (ROOT / 'fixtures/baseline.html').read_text())
    store.close()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), partial(Handler, directory=str(ROOT / 'public')))
    server.db_path = args.db
    print(f'Local preview: http://127.0.0.1:{server.server_port}', flush=True)
    server.serve_forever()

if __name__ == '__main__':
    main()
