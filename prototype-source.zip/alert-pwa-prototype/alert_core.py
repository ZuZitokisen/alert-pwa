"""Local-only semantic calendar diff prototype. Python 3.12+, no dependencies."""
from __future__ import annotations
from datetime import date, datetime, timezone
from hashlib import sha256
from html.parser import HTMLParser
import json
import re
import sqlite3

STATUSES = {'possible', 'confirmed', 'cancelled', 'unknown'}
FIELDS = ('title', 'start', 'end', 'allDay', 'status', 'category', 'location', 'note', 'evidence')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def normalized(value):
    return re.sub(r'\s+', ' ', value or '').strip()


def when(value):
    if not value:
        return None
    if re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        return date.fromisoformat(value).isoformat()
    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if dt.tzinfo is None:
        raise ValueError('時刻には明示的なタイムゾーンが必要です')
    return dt.astimezone(timezone.utc).isoformat().replace('+00:00', 'Z')


class CalendarParser(HTMLParser):
    """Deliberate adapter for a documented sample contract, not arbitrary HTML."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.marker = False
        self.empty_allowed = False
        self.events = []
        self.stack = []
        self.complete = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get('data-alert-calendar') == 'v1':
            if self.marker:
                raise ValueError('複数のカレンダー領域は扱えません')
            self.marker = True
            self.empty_allowed = a.get('data-empty') == 'true'
            self.stack = [tag]
        elif self.stack and tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(tag)
        if 'data-event-id' not in a:
            return
        if not self.stack:
            raise ValueError('カレンダー領域の外に予定があります')
        key = normalized(a['data-event-id'])
        title = normalized(a.get('data-title'))
        if not key or not title or len(key) > 200:
            raise ValueError('予定ID・タイトルが不足しています')
        status = a.get('data-status', 'unknown')
        if status not in STATUSES:
            raise ValueError('未知の確度です。自動で確定へ変換しません')
        start, end = when(a.get('data-start')), when(a.get('data-end'))
        if end and not start:
            raise ValueError('開始のない終了は扱えません')
        if start and end:
            if (len(start) == 10) != (len(end) == 10):
                raise ValueError('開始・終了の形式が不正です')
            parse = date.fromisoformat if len(start) == 10 else datetime.fromisoformat
            if parse(end) < parse(start):
                raise ValueError('開始・終了の順序が不正です')
        all_day = a.get('data-all-day') == 'true'
        if all_day and (not start or len(start) != 10):
            raise ValueError('終日予定には日付が必要です')
        self.events.append({
            'id': key, 'title': title, 'start': start, 'end': end, 'allDay': all_day,
            'status': status, 'category': normalized(a.get('data-category', 'EVENT')),
            'location': normalized(a.get('data-location')), 'note': normalized(a.get('data-note')),
            'evidence': normalized(a.get('data-evidence')),
        })

    def handle_endtag(self, tag):
        if not self.stack:
            return
        if self.stack[-1] != tag:
            raise ValueError('カレンダーHTMLの構造が不完全です')
        self.stack.pop()
        if not self.stack:
            self.complete = True


def parse_calendar(html):
    if len(html.encode('utf-8')) > 2_000_000:
        raise ValueError('HTMLが大きすぎます')
    p = CalendarParser()
    p.feed(html)
    p.close()
    if not p.marker or not p.complete:
        raise ValueError('対象カレンダーを確認できません。ログイン画面や取得失敗の可能性があります')
    if not p.events and not p.empty_allowed:
        raise ValueError('予定が0件です。空カレンダーの明示がないため前回値を保持します')
    ids = [e['id'] for e in p.events]
    if len(ids) != len(set(ids)):
        raise ValueError('予定IDが重複しています')
    return sorted(p.events, key=lambda e: e['id'])


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path, timeout=15)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
          CREATE TABLE IF NOT EXISTS sources (
            id TEXT PRIMARY KEY, hash TEXT NOT NULL, checked TEXT NOT NULL, error TEXT
          );
          CREATE TABLE IF NOT EXISTS events (
            source TEXT NOT NULL, id TEXT NOT NULL, data TEXT NOT NULL,
            revision INTEGER NOT NULL, present INTEGER NOT NULL,
            PRIMARY KEY(source,id)
          );
          CREATE TABLE IF NOT EXISTS changes (
            id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL,
            event_id TEXT NOT NULL, kind TEXT NOT NULL, revision INTEGER NOT NULL,
            before_json TEXT, after_json TEXT, fields TEXT NOT NULL, detected TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS outbox (
            change_id INTEGER PRIMARY KEY REFERENCES changes(id),
            payload TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'prepared'
          );
        ''')

    def close(self):
        self.db.close()

    def ingest(self, source, html, now=None):
        now = now or datetime.now(timezone.utc).isoformat()
        try:
            events = parse_calendar(html)
        except ValueError as exc:
            with self.db:
                self.db.execute('UPDATE sources SET error=? WHERE id=?', (str(exc), source))
            raise
        digest = sha256(canonical(events).encode()).hexdigest()
        changes = []
        try:
            # Serializes compare + write + outbox in the same transaction.
            self.db.execute('BEGIN IMMEDIATE')
            prior = self.db.execute('SELECT hash FROM sources WHERE id=?', (source,)).fetchone()
            if prior and prior['hash'] == digest:
                self.db.execute('UPDATE sources SET checked=?,error=NULL WHERE id=?', (now, source))
                self.db.commit()
                return []
            previous = {r['id']: dict(r) for r in self.db.execute('SELECT * FROM events WHERE source=?', (source,))}
            incoming = {e['id']: e for e in events}
            for key in sorted(set(previous) | set(incoming)):
                old = previous.get(key)
                before = json.loads(old['data']) if old else None
                after = incoming.get(key)
                revision = old['revision'] if old else 0
                if not after and (not old or not old['present']):
                    continue
                kind = 'new' if not old else ('unavailable' if after is None else ('restored' if not old['present'] else 'updated'))
                fields = [f for f in FIELDS if (before or {}).get(f) != (after or {}).get(f)]
                if old and old['present'] and after is not None and not fields:
                    continue
                revision += 1
                if after is None:
                    self.db.execute('UPDATE events SET present=0,revision=? WHERE source=? AND id=?', (revision, source, key))
                else:
                    self.db.execute('INSERT INTO events VALUES(?,?,?,?,1) ON CONFLICT(source,id) DO UPDATE SET data=excluded.data,revision=excluded.revision,present=1', (source, key, canonical(after), revision))
                # First successful capture is a baseline, not a notification storm.
                if not prior:
                    continue
                cur = self.db.execute('INSERT INTO changes(source,event_id,kind,revision,before_json,after_json,fields,detected) VALUES(?,?,?,?,?,?,?,?)', (source, key, kind, revision, canonical(before), canonical(after), canonical(fields), now))
                cid = cur.lastrowid
                payload = {'changeId': cid, 'eventId': key, 'revision': revision, 'url': '/#changes', 'title': 'フォロー中の情報に更新があります', 'body': 'アプリで変更内容と根拠を確認してください', 'tag': f'alert-{source}-{key}'}
                self.db.execute('INSERT INTO outbox(change_id,payload) VALUES(?,?)', (cid, canonical(payload)))
                changes.append(cid)
            self.db.execute('INSERT INTO sources VALUES(?,?,?,NULL) ON CONFLICT(id) DO UPDATE SET hash=excluded.hash,checked=excluded.checked,error=NULL', (source, digest, now))
            self.db.commit()
            return changes
        except Exception:
            self.db.rollback()
            raise

    def state(self):
        events = []
        for row in self.db.execute('SELECT * FROM events ORDER BY source,id'):
            events.append({**json.loads(row['data']), 'source': row['source'], 'revision': row['revision'], 'present': bool(row['present'])})
        changes = []
        for row in self.db.execute('SELECT * FROM changes ORDER BY id DESC'):
            changes.append({'id': row['id'], 'source': row['source'], 'eventId': row['event_id'], 'kind': row['kind'], 'revision': row['revision'], 'before': json.loads(row['before_json']), 'after': json.loads(row['after_json']), 'fields': json.loads(row['fields']), 'detected': row['detected']})
        return {'events': events, 'changes': changes, 'sources': [dict(r) for r in self.db.execute('SELECT id,checked,error FROM sources')], 'outboxCount': self.db.execute('SELECT count(*) FROM outbox').fetchone()[0], 'pushConfigured': False, 'demo': True}
