from functools import partial
from http.server import ThreadingHTTPServer
import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from server import Handler,ROOT
from alert_core import Store

class QuietHandler(Handler):
 def log_message(self,*args):pass
class ServerTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory();cls.db=str(Path(cls.temp.name)/'api.sqlite3')
  st=Store(cls.db);st.ingest('demo-calendar',(ROOT/'fixtures/baseline.html').read_text());st.close()
  cls.server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(ROOT/'public')));cls.server.db_path=cls.db
  cls.port=cls.server.server_port;cls.origin=f'http://127.0.0.1:{cls.port}';cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join();cls.temp.cleanup()
 def request(self,method,path,body=None,headers=None):
  conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=3);conn.request(method,path,body,headers or {});r=conn.getresponse();result=(r.status,dict(r.getheaders()),r.read());conn.close();return result
 def post(self,data,origin=None):return self.request('POST','/api/demo',json.dumps(data),{'Content-Type':'application/json','Origin':origin or self.origin})
 def test_read(self):
  status,headers,data=self.request('GET','/api/state');self.assertEqual(status,200);self.assertTrue(json.loads(data)['demo']);self.assertEqual(headers['Cache-Control'],'no-store')
 def test_static_shell(self):
  for path in ['/','/manifest.webmanifest','/icon-192.png','/icon-512.png','/sw.js','/app.js']:
   status,headers,data=self.request('GET',path);self.assertEqual(status,200,path);self.assertTrue(data)
 def test_unknown_path(self):self.assertEqual(self.request('GET','/../server.py')[0],404)
 def test_host_guard(self):self.assertEqual(self.request('GET','/api/state',headers={'Host':'evil.invalid'})[0],403)
 def test_origin_guard(self):self.assertEqual(self.post({'step':'update'},'https://evil.invalid')[0],403)
 def test_missing_origin(self):self.assertEqual(self.request('POST','/api/demo','{}',{'Content-Type':'application/json'})[0],403)
 def test_wrong_type(self):
  for value in [[],{},123,None]:self.assertEqual(self.post({'step':value})[0],400)
 def test_array_body(self):self.assertEqual(self.post([])[0],400)
 def test_malformed_json(self):self.assertEqual(self.request('POST','/api/demo','{',{'Content-Type':'application/json','Origin':self.origin})[0],400)
 def test_update_and_repeat(self):
  status,_,body=self.post({'step':'update'});self.assertEqual(status,200);self.assertEqual(json.loads(body)['newChanges'],3)
  self.assertEqual(json.loads(self.post({'step':'update'})[2])['newChanges'],0)
 def test_failed_html_not_data_loss(self):
  before=json.loads(self.request('GET','/api/state')[2]);status,_,body=self.post({'step':'failure'});self.assertEqual(status,422);self.assertEqual(json.loads(body)['state']['events'],before['events'])
if __name__=='__main__':unittest.main(verbosity=2)
