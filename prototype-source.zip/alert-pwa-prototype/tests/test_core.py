import json
from pathlib import Path
import tempfile
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from alert_core import Store,parse_calendar
ROOT=Path(__file__).resolve().parents[1]
BASE=(ROOT/'fixtures/baseline.html').read_text()
UPDATE=(ROOT/'fixtures/update.html').read_text()
MISSING=(ROOT/'fixtures/unavailable.html').read_text()
class CoreTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.path=str(Path(self.temp.name)/'test.sqlite3');self.store=Store(self.path);self.store.ingest('sample',BASE)
 def tearDown(self):self.store.close();self.temp.cleanup()
 def test_baseline_quiet(self):
  s=self.store.state();self.assertEqual(len(s['events']),4);self.assertEqual(s['outboxCount'],0)
 def test_field_diff(self):
  self.assertEqual(len(self.store.ingest('sample',UPDATE)),3)
  c={c['eventId']:c for c in self.store.state()['changes']}
  self.assertEqual(c['ticket-005']['kind'],'new');self.assertEqual(c['stream-001']['before']['status'],'possible');self.assertEqual(c['stream-001']['after']['status'],'confirmed');self.assertEqual(set(c['live-002']['fields']),{'start','end'});self.assertIn('evidence',c['stream-001']['fields'])
 def test_dedup(self):
  self.store.ingest('sample',UPDATE);self.assertEqual(self.store.ingest('sample',UPDATE),[]);self.assertEqual(self.store.state()['outboxCount'],3)
 def test_whitespace_and_chrome(self):
  self.assertEqual(self.store.ingest('sample',BASE.replace('週末ライブ','  週末ライブ  ').replace('</body>','<p>time:12:00</p></body>')),[])
 def test_reorder(self):
  lines=BASE.splitlines();self.assertEqual(self.store.ingest('sample','\n'.join(lines[:2]+list(reversed(lines[2:6]))+lines[6:])),[])
 def test_timezone_equivalence(self):
  self.assertEqual(self.store.ingest('sample',BASE.replace('2026-11-14T19:00:00+09:00','2026-11-14T10:00:00Z')),[])
 def test_failure_preserves(self):
  self.store.ingest('sample',UPDATE);before=self.store.state()
  with self.assertRaises(ValueError):self.store.ingest('sample','<h1>Login required</h1>')
  after=self.store.state();self.assertEqual(after['events'],before['events']);self.assertEqual(after['changes'],before['changes']);self.assertEqual(after['outboxCount'],before['outboxCount']);self.assertTrue(after['sources'][0]['error'])
  self.store.ingest('sample',UPDATE);self.assertIsNone(self.store.state()['sources'][0]['error'])
 def test_unexplained_empty_rejected(self):
  with self.assertRaises(ValueError):self.store.ingest('sample','<main data-alert-calendar="v1"></main>')
  self.assertEqual(len(self.store.state()['events']),4)
 def test_explicit_empty_not_cancellation(self):
  self.store.ingest('sample','<main data-alert-calendar="v1" data-empty="true"></main>');s=self.store.state();self.assertTrue(all(c['kind']=='unavailable' for c in s['changes']));self.assertTrue(all(not e['present'] and e['status']!='cancelled' for e in s['events']))
 def test_missing_and_restored(self):
  self.store.ingest('sample',UPDATE);self.store.ingest('sample',MISSING);s=self.store.state();e=next(e for e in s['events'] if e['id']=='radio-003');self.assertFalse(e['present']);self.assertEqual(e['status'],'possible');self.assertEqual(s['changes'][0]['kind'],'unavailable');self.assertEqual(self.store.ingest('sample',MISSING),[]);self.store.ingest('sample',UPDATE);self.assertEqual(self.store.state()['changes'][0]['kind'],'restored')
 def test_revision_on_revert(self):
  self.store.ingest('sample',UPDATE);self.store.ingest('sample',BASE);self.assertEqual(next(e for e in self.store.state()['events'] if e['id']=='stream-001')['revision'],3)
 def test_namespaces(self):
  self.store.ingest('another',BASE);self.assertEqual(len(self.store.state()['events']),8)
 def test_duplicate_id_rejected(self):
  with self.assertRaises(ValueError):self.store.ingest('sample',BASE.replace('live-002','stream-001'))
  self.assertEqual(self.store.state()['outboxCount'],0)
 def test_unknown_not_confirmed(self):
  self.store.ingest('sample',BASE.replace('data-status="confirmed"',''));self.assertEqual(next(e for e in self.store.state()['events'] if e['id']=='live-002')['status'],'unknown')
  with self.assertRaises(ValueError):parse_calendar(BASE.replace('data-status="confirmed"','data-status="likely"'))
 def test_date_without_time_not_all_day(self):
  e=next(e for e in self.store.state()['events'] if e['id']=='radio-003');self.assertEqual(e['start'],'2026-11-18');self.assertFalse(e['allDay'])
 def test_invalid_date(self):
  with self.assertRaises(ValueError):parse_calendar(BASE.replace('2026-11-18','2026-02-30'))
 def test_naive_time(self):
  with self.assertRaises(ValueError):parse_calendar(BASE.replace('2026-11-14T19:00:00+09:00','2026-11-14T19:00:00'))
 def test_reverse_time(self):
  with self.assertRaises(ValueError):parse_calendar(BASE.replace('2026-11-14T20:00:00+09:00','2026-11-14T18:00:00+09:00'))
 def test_fractional_time(self):
  html='<main data-alert-calendar="v1"><article data-event-id="a" data-title="a" data-start="2026-11-14T12:00:00Z" data-end="2026-11-14T12:00:00.100Z"></article></main>'
  self.assertEqual(len(parse_calendar(html)),1)
  with self.assertRaises(ValueError):parse_calendar(html.replace('data-start="2026-11-14T12:00:00Z" data-end="2026-11-14T12:00:00.100Z"','data-start="2026-11-14T12:00:00.100Z" data-end="2026-11-14T12:00:00Z"'))
 def test_truncated_html(self):
  with self.assertRaises(ValueError):self.store.ingest('sample',BASE.split('<article data-event-id="live-002"')[0])
  self.assertEqual(self.store.state()['outboxCount'],0)
 def test_outside_calendar(self):
  with self.assertRaises(ValueError):parse_calendar('<article data-event-id="a" data-title="a"></article><main data-alert-calendar="v1" data-empty="true"></main>')
 def test_restart_dedup(self):
  self.store.ingest('sample',UPDATE);self.store.close();self.store=Store(self.path);self.assertEqual(self.store.ingest('sample',UPDATE),[])
 def test_outbox_generic(self):
  self.store.ingest('sample',UPDATE)
  for r in self.store.db.execute('SELECT * FROM outbox'):
   self.assertEqual(r['state'],'prepared');self.assertEqual(json.loads(r['payload'])['url'],'/#changes');self.assertNotIn('秋のスペシャル配信',r['payload'])
 def test_transaction_rollback(self):
  self.store.db.execute('CREATE TRIGGER fail_outbox BEFORE INSERT ON outbox BEGIN SELECT RAISE(FAIL, "test failure"); END;');before=self.store.state()
  with self.assertRaises(Exception):self.store.ingest('sample',UPDATE)
  self.assertEqual(self.store.state(),before)
if __name__=='__main__':unittest.main(verbosity=2)
