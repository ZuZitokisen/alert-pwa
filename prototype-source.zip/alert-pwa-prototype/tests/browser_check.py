"""Optional QA: requires Playwright and a locally installed Chromium."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:8765'
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 ctx=browser.new_context(viewport={'width':1440,'height':1100},device_scale_factor=1)
 page=ctx.new_page();errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(BASE);page.wait_for_function("document.querySelector('#count-all').textContent==='4'")
 page.evaluate('navigator.serviceWorker.ready');page.reload();page.wait_for_function('navigator.serviceWorker.controller!==null')
 page.screenshot(path=str(ROOT/'qa/desktop.png'),full_page=True)
 assert page.locator('.card').count()==4
 page.locator('[data-filter="possible"]').click();assert page.locator('#cards .card').count()==2
 page.locator('#search').fill('ラジオ');assert page.locator('#cards .card').count()==1
 page.locator('#cards .card').click();assert page.locator('dialog').is_visible();page.keyboard.press('Escape');assert not page.locator('dialog').is_visible()
 page.locator('#search').fill('');page.locator('[data-filter="all"]').click()
 page.locator('[data-step="update"]').click();page.wait_for_function("document.querySelector('#count-all').textContent==='5'")
 assert page.locator('#unread').inner_text()=='3'
 page.locator('[data-step="update"]').click();page.wait_for_timeout(250);assert page.locator('#unread').inner_text()=='3'
 page.locator('[data-view="changes"]').click();assert page.locator('.change').count()==3
 page.locator('.change').filter(has_text='秋のスペシャル配信').click();assert '可能性' in page.locator('dialog').inner_text() and '確定' in page.locator('dialog').inner_text()
 page.locator('#close-detail').click();page.locator('#read-all').click();assert page.locator('#unread').inner_text()=='0'
 page.locator('[data-step="unavailable"]').click();page.wait_for_function("document.querySelector('#unread').textContent==='1'");assert page.locator('.change').count()==4
 page.locator('[data-step="failure"]').click();page.wait_for_function("document.querySelector('#connection').textContent.includes('取得失敗')");assert page.locator('.change').count()==4
 page.locator('[data-view="watch"]').click();assert page.locator('#cards .card').count()==5;assert page.locator('#cards .missing').count()==1
 page.locator('[data-view="calendar"]').click();assert page.locator('.calendar-event').count()==5
 page.locator('#next-month').click();assert page.locator('#month-label').inner_text()=='2026年 12月'
 page.go_back();assert page.locator('#watch-view').is_visible()
 page.locator('[data-view="settings"]').click();assert page.get_by_text('配信環境の設定後に有効化').is_disabled()
 page.locator('[data-view="watch"]').click()
 ctx.set_offline(True);page.reload();page.wait_for_function("document.querySelector('#connection').textContent.includes('オフライン表示')");assert page.locator('#cards .card').count()==5
 ctx.set_offline(False);page.reload();page.wait_for_function("!document.querySelector('#connection').textContent.includes('オフライン表示')")
 # Malformed and cross-origin POST must fail closed.
 result=page.evaluate("""async()=>{const r=await fetch('/api/demo',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({step:[]})});return r.status;}""")
 assert result==400
 response=ctx.request.post(BASE+'/api/demo',data={'step':'update'},headers={'Origin':'https://untrusted.invalid','Content-Type':'application/json'})
 assert response.status==403
 mobile=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
 mp=mobile.new_page();mp.on('pageerror',lambda e:errors.append(str(e)));mp.goto(BASE);mp.wait_for_function("document.querySelector('#cards').children.length===5")
 assert mp.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
 mp.screenshot(path=str(ROOT/'qa/mobile.png'),full_page=True)
 mp.locator('#cards .card').first.click();assert mp.locator('dialog').is_visible();mp.locator('#close-detail').click();mp.locator('[data-view="calendar"]').click();assert mp.evaluate('document.documentElement.scrollWidth<=window.innerWidth')
 mp.screenshot(path=str(ROOT/'qa/mobile-calendar.png'),full_page=True)
 assert errors==[],errors
 (ROOT/'qa/browser-result.json').write_text(json.dumps({'status':'passed','browser':'Chromium','desktop':'1440x1100','mobile':'390x844','pageErrors':errors,'checks':['filters/search/detail/Escape','field diffs','duplicate suppression','missing vs cancelled','failure retention','read markers','month navigation','back navigation','offline shell and cached synthetic data','malformed POST rejection','cross-origin POST rejection','mobile overflow']},indent=2,ensure_ascii=False))
 browser.close()
 print('Browser QA passed: desktop, mobile, interrupted/repeated flows, offline, API guards. No JS page errors.')
